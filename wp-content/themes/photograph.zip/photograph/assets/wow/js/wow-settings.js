jQuery( function() {
	
	// For Wow Effect
	var wow = new WOW({
		boxClass: 'freesia-animation',
    	mobile: false
	});
	wow.init();

} );